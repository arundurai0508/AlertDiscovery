from flask import jsonify, Flask, request, json, Blueprint
import requests, psycopg2
from Alert_Discovery.db_config.config import database, login

import Alert_Discovery.db_config.config

grafana_url = Alert_Discovery.db_config.config.grafana_url.base_url
grafana_username = Alert_Discovery.db_config.config.grafana_url.username
grafana_password = Alert_Discovery.db_config.config.grafana_url.password
grafana_headers = Alert_Discovery.db_config.config.grafana_url.headers

grafana_alert_rules = Alert_Discovery.db_config.config.grafana_url.alert_rules
grafana_contact_points = Alert_Discovery.db_config.config.grafana_url.contact_points
grafana_notification_policies = Alert_Discovery.db_config.config.grafana_url.notification_policies
grafana_folders = Alert_Discovery.db_config.config.grafana_url.folders
grafana_dashboard = Alert_Discovery.db_config.config.grafana_url.dashboard
grafana_datasource = Alert_Discovery.db_config.config.grafana_url.datasource
grafana_panel = Alert_Discovery.db_config.config.grafana_url.panel


app_h = Blueprint('app_h', __name__)


def create_policies(name, object):
    try:
        base_url = grafana_url
        s = requests.Session()
        s.auth = (grafana_username, grafana_password)
        headers = grafana_headers

        payload = {'receiver': name, 'object_matchers': object}

        response = s.get(base_url + grafana_notification_policies, headers=headers, data=json.dumps(payload))
        datas = response.json()

        if 'routes' not in datas:
            l = [payload]
            datas['routes'] = l
        else:
            datas['routes'].append(payload)
        response = s.put(base_url + grafana_notification_policies, headers=headers, data=json.dumps(datas))

        return ({"result": "success", "message": response.text})
    except:
        return ({"result": "failure", "message": "Something Went Wrong!!!"})


def delete_policies(name):
    try:

        base_url = grafana_url
        s = requests.Session()
        s.auth = (grafana_username, grafana_password)
        headers = grafana_headers

        response = s.get(base_url + grafana_notification_policies, headers=headers)
        datas = response.json()
        if 'routes' not in datas:
            return ({"result": "success"})
        else:
            data = datas['routes']
            dl = []

            for i in range(len(data)):
                if data[i]['receiver'] != name:
                    dl.append(data[i])

            if len(data) > 0:

                del datas['routes']
                # l = data
                datas['routes'] = dl

                response = s.put(base_url + grafana_notification_policies, headers=headers, data=json.dumps(datas))

                if response.status_code == 202:
                    return ({"result": "success", "message": response.text})
                else:
                    return ({"result": "failure", "message": response.text})
            else:
                del datas['routes']
                response = s.put(base_url + grafana_notification_policies, headers=headers, data=json.dumps(datas))

                if response.status_code == 202:
                    return ({"result": "success", "message": response.text})
                else:
                    return ({"result": "failure", "message": response.text})


    except Exception as e:
        return ({"result": "failure", "message": e})


def getall_contactPoints():
    try:
        base_url = grafana_url
        s = requests.Session()
        s.auth = (grafana_username, grafana_password)

        response = s.get(base_url + grafana_contact_points, verify=False)
        data = response.json()

        return ({"result": "success", "data": data})
    except:
        return ({"result": "failure", "message": "Something Went Wrong!!!"})


@app_h.route("/api/v1/contact-point/create", methods=['POST'])
@login
def create_contact(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()
        try:
            data = request.get_json()
            query = "select * from contactpoints where name='{0}'".format(data['name'])
            cur.execute(query)
            out = cur.fetchall()

            if out:
                return ({"type": "failed", "message": "name should be unique!!!"})

            type = data['type']
            if type == 'email':
                addresses = data['address']
                url = None
                token = None
                channel = None
                chatid = None
                bottoken = None
            elif type == 'slack':
                addresses = None
                url = data['url']
                token = None
                channel = data['channel']
                chatid = None
                bottoken = None
            elif type == 'telegram':
                addresses = None
                url = None
                token = None
                channel = None
                chatid = data['chatid']
                bottoken = data['bottoken']
            elif type == 'webhook' or type == 'discord':
                addresses = None
                url = data['url']
                token = None
                channel = None
                chatid = None
                bottoken = None
            else:
                return ({"result": "failure", "message": "unsupported type"})

            base_url = grafana_url
            s = requests.Session()
            s.auth = (grafana_username, grafana_password)
            headers = grafana_headers

            payload = {

                "name": data['name'],
                "type": data['type'],
                "isDefault": False,
                "sendReminder": False,
                "secureSettings": {
                    "bottoken": bottoken
                },
                "settings": {
                    "addresses": addresses,
                    "url": url,
                    "token": token,
                    "channel": channel,
                    "chatid": chatid
                }
            }
            response = s.post(base_url + grafana_contact_points, headers=headers, data=json.dumps(payload))
            if response.status_code == 202:

                contact = response.json()
                uid = contact['uid']
                name = contact['name']
                type = contact['type']
                settings = contact['settings']

                try:

                    query = ("insert into contactpoints(uid,name,type,settings,labels) VALUES('{0}', '{1}','{2}',"
                             "'{3}', ARRAY{4})").format(
                        uid, name, type, json.dumps(settings), data.get('object_matchers')[0])
                    cur.execute(query)
                    conn.commit()
                except Exception as e:
                    s.delete(base_url + f"{grafana_contact_points}/{uid}")

                    return ({"result": "failure", "message": "Something Went Wrong... Try After Somtimes!!!"})

                result = create_policies(data['name'], data['object_matchers'])
                if result['result'] == "success":
                    return ({"result": "success", "message": "Contact-Point and policies Created!!!"})
                else:
                    s.delete(base_url + f"{grafana_contact_points}/{uid}")
                    return ({"result": "failure", "message": "Something Went Wrong... Try After Somtimes!!!"})
        except Exception as e:
            return ({"result": "failure", "message": e})
        finally:
            conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})


@app_h.route("/api/v1/contact-point/update", methods=['PUT'])
@login
def update_contactPoints(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()

        global settings
        try:
            data = request.get_json()
            query = "select * from contactpoints where contact_id={0}".format(data['id'])
            cur.execute(query)
            out = cur.fetchone()
            uid = out[1]
            name = out[3]
            if name == data['name']:
                pass
            else:

                query = "SELECT * from contactpoints where name = '{0}' AND contact_id != {1}".format(data['name'],
                                                                                                      data['id'])
                cur.execute(query)
                res = cur.fetchall()
                if res:
                    return ({"type": "failed", "message": "name should be unique!!!"})
            type = data['type']
            if type == 'email':
                addresses = data['address']
                url = None
                token = None
                channel = None
                chatid = None
                bottoken = None
            elif type == 'slack':
                addresses = None
                url = data['url']
                token = None
                channel = data['channel']
                chatid = None
                bottoken = None
            elif type == 'telegram':
                addresses = None
                url = None
                token = None
                channel = None
                chatid = data['chatid']
                bottoken = data['bottoken']
            elif type == 'webhook' or type == 'discord':
                addresses = None
                url = data['url']
                token = None
                channel = None
                chatid = None
                bottoken = None
            else:
                return ({"result": "failure", "message": "unsupported type"})

            base_url = grafana_url
            s = requests.Session()
            s.auth = (grafana_username, grafana_password)
            headers = grafana_headers

            payload = {

                "name": data['name'],
                "type": data['type'],
                "isDefault": False,
                "sendReminder": False,
                "secureSettings": {
                    "bottoken": bottoken
                },
                "settings": {
                    "addresses": addresses,
                    "url": url,
                    "token": token,
                    "channel": channel,
                    "chatid": chatid
                }
            }
            response = s.put(base_url + f"{grafana_contact_points}/{uid}", headers=headers,
                             data=json.dumps(payload))

            if response.status_code == 202:

                name = data['name']
                type = data['type']
                all = getall_contactPoints()
                if all['result'] == 'success':
                    contacts = all['data']
                    for i in contacts:
                        if i['uid'] == uid:
                            settings = i['settings']

                try:
                    query = "update contactpoints  set name='{0}',type='{1}',settings='{2}' where contact_id={3};".format(
                        name, type, json.dumps(settings), data['id'])
                    cur.execute(query)
                    conn.commit()
                except Exception as e:

                    return ({"result": "failure", "message": "Something Went Wrong... Try After Somtimes!!!"})

                out = delete_policies(name)
                print(out)
                result = create_policies(data['name'], data['object_matchers'])
                if result['result'] == "success":
                    return ({"result": "success", "message": "Contact-Point and policies Updated!!!"})
                else:

                    return ({"result": "failure", "message": "Something Went Wrong... Try After Somtimes!!!"})
        except Exception as e:
            return ({"result": "failure", "message": "Something Went Wrong"})
        finally:
            conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})


@app_h.route("/api/v1/contact-point/get_All", methods=['GET'])
@login
def get_all_contact_points(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()
        try:
            query = "SELECT * FROM contactpoints"
            cur.execute(query)
            cols = [column[0] for column in cur.description]
            rows = cur.fetchall()
            ll = []

            if len(rows) > 0:
                for eachRow in rows:
                    ll.append(dict(zip(cols, eachRow)))

            if ll != []:
                return jsonify({"type": "success", "contactpoints": ll})
            else:
                return jsonify({"type": "error", "message": "No alert contact points found"})

        except Exception as e:
            return jsonify({"type": "error", "message": f"Error: {str(e)}"})
        finally:
            conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})


@app_h.route("/api/v1/contact-point/get_single", methods=['GET'])
@login
def get_contact_point(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()
        try:
            id = request.args.get('id')

            if not id:
                return jsonify({"message": "Alert ID is missing"}), 400

            query = "SELECT * FROM contactpoints WHERE contact_id = %s"
            cur.execute(query, (id,))
            cols = [column[0] for column in cur.description]
            rows = cur.fetchall()
            ll = []

            if len(rows) > 0:
                for eachRow in rows:
                    ll.append(dict(zip(cols, eachRow)))

            if ll != []:
                return jsonify({"type": "success", "contact_details": ll})
            else:
                return jsonify({"type": "error", "message": f"No contact points found with ID {id}"}), 404

        except Exception as e:
            return jsonify({"type": "error", "message": f"Error: {str(e)}"}), 500
        finally:
            conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})


@app_h.route("/api/v1/contact-point/delete", methods=['DELETE'])
@login
def delete_contact_point(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()

        id = request.args.get('id')
        if not id:
            return jsonify({"message": "contact ID is missing"}), 400

        base_url = grafana_url
        s = requests.Session()
        s.auth = (grafana_username, grafana_password)

        try:
            query = """SELECT * from contactpoints WHERE contact_id='{0}' """.format(id)
            cur.execute(query)
            res = cur.fetchone()
            uid = res[1]
            name = res[3]
            del_policies = delete_policies(name)

            if del_policies['result'] == 'success':

                query = """DELETE from contactpoints WHERE contact_id={0}""".format(id)
                cur.execute(query)
                conn.commit()

                response = s.delete(base_url + f"{grafana_contact_points}/{uid}")
                if response.status_code == 202:
                    return jsonify({"result": "Success", "message": "contact deleted successfully!!"})
                else:
                    return ({"type": "Failed", "message": "try after sometimes"})
            else:
                return del_policies
        except Exception as e:
            print(e)
            return jsonify({"type": "error", "message": f"Error: {str(e)}"})
        finally:
            conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})
