from flask import Flask

from Alert_Discovery.Alert_CRUD.Amazon_EC2 import app_a
from Alert_Discovery.Alert_CRUD.Network_Device_Dashboard import app_b
from Alert_Discovery.Alert_CRUD.Network_Utilization_Dashboard import app_c
from Alert_Discovery.Alert_CRUD.Operating_System_Metrics import app_d
from Alert_Discovery.Alert_CRUD.Ping_Network_Uptime import app_e
from Alert_Discovery.Alert_details.Alert_Payload import app_f
from Alert_Discovery.Alert_details.Alert_Thresholds import app_g
from Alert_Discovery.Contact_details.Contact_details import app_h
from Alert_Discovery.Dashboard_details.Dashboard_details import app_i
from Alert_Discovery.db_config.config import app_j
from Alert_Discovery.db_config.models import app_k

app = Flask(__name__)

app.register_blueprint(app_a, url='/api/v1/Amazon-EC2/create,/api/v1/Amazon-EC2/update')
app.register_blueprint(app_b, url='/api/v1/Network-Device-Dashboard/create,/api/v1/Network-Device-Dashboard/update')
app.register_blueprint(app_c, url='/api/v1/Network-Utilization-Dashboard/create,'
                                  '/api/v1/Network-Utilization-Dashboard/update')
app.register_blueprint(app_d, url='/api/v1/Operating-System-Metrics/create,/api/v1/Operating-System-Metrics/update,'
                                  '/api/v1/Operating-System-Internet/create,/api/v1/Operating-System-Internet/update')
app.register_blueprint(app_e, url='/api/v1/Ping-Network-Uptime/create,/api/v1/Ping-Network-Uptime/update')
app.register_blueprint(app_f, url='/api/v1/get_alert_payload,/api/v1/single_alert_payload,/api/v1/delete_alert_payload')
app.register_blueprint(app_g, url='/api/v1/get_alert_thresholds,/api/v1/single_alert_thresholds,'
                                  '/api/v1/delete_alert_thresholds')
app.register_blueprint(app_h, url='/api/v1/contact-point/create,/api/v1/contact-point/update,'
                                  '/api/v1/contact-point/get_All,/api/v1/contact-point/get_single,'
                                  '/api/v1/contact-point/delete')
app.register_blueprint(app_i, url='/api/v1/get_all_dashboard,/api/v1/get_all_panel_details,'
                                  '/api/v1/get_all_datasource,/api/v1/get_all_folders')
app.register_blueprint(app_j, url='/config')
app.register_blueprint(app_k, url='/models')

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
