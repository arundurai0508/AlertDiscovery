from flask import Blueprint, jsonify, request
import requests
from Alert_Discovery.db_config.config import login
import Alert_Discovery.db_config.config
grafana_url = Alert_Discovery.db_config.config.grafana_url.base_url
grafana_username = Alert_Discovery.db_config.config.grafana_url.username
grafana_password = Alert_Discovery.db_config.config.grafana_url.password
grafana_headers = Alert_Discovery.db_config.config.grafana_url.headers

grafana_alert_rules = Alert_Discovery.db_config.config.grafana_url.alert_rules
grafana_contact_points = Alert_Discovery.db_config.config.grafana_url.contact_points
grafana_notification_policies = Alert_Discovery.db_config.config.grafana_url.notification_policies
grafana_folders = Alert_Discovery.db_config.config.grafana_url.folders
grafana_dashboard = Alert_Discovery.db_config.config.grafana_url.dashboard
grafana_datasource = Alert_Discovery.db_config.config.grafana_url.datasource
grafana_panel = Alert_Discovery.db_config.config.grafana_url.panel


app_f = Blueprint('app', __name__)


@app_f.route("/api/v1/get_alert_payload", methods=["GET"])
@login
def get_alert_payload(*args):
    if args[0] == True:
        base_url = grafana_url
        s = requests.Session()
        s.auth = (grafana_username, grafana_password)

        try:
            resp = s.get(base_url + grafana_alert_rules, verify=False)
            resp.raise_for_status()
            data = resp.json()

            if not data:
                raise Exception("No alerts found")

            return jsonify({"type": "success", "data": data})

        except Exception as e:
            return jsonify({"type": "error", "message": f"No alerts created: {str(e)}"})
    # else:
    #     return ({"type": "error", "message": "Login failed"})

@app_f.route("/api/v1/single_alert_payload", methods=["GET"])
@login
def single_alert_payload(*args):
    if args[0] == True:
        try:
            id = request.args.get('id')
            if not id:
                return jsonify({"error": "Alert ID not provided"}), 400

            base_url = grafana_url
            s = requests.Session()
            s.auth = (grafana_username, grafana_password)

            resp = s.get(f"{base_url}{grafana_alert_rules}/{id}", verify=False)
            data = resp.json()

            return jsonify(data), resp.status_code
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    else:
        return ({"type": "error", "message": "Login failed"})

@app_f.route("/api/v1/delete_alert_payload", methods=['DELETE'])
@login
def delete_alert_payload(*args):
    if args[0] == True:
        id = request.args['id']

        base_url = grafana_url
        s = requests.Session()
        s.auth = (grafana_username, grafana_password)

        response = s.delete(base_url + f"{grafana_alert_rules}/{id}")

        if response.status_code == 204:
            return jsonify({"type": "success", "message": "Alert deleted successfully"})
        else:
            return jsonify({"type": "error", "message": f"Failed to delete alert: {response.text}"})
    else:
        return ({"type": "error", "message": "Login failed"})