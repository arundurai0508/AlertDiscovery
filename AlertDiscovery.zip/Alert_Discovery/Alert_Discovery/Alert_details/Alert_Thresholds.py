from flask import Blueprint, jsonify, request
import requests, psycopg2
from Alert_Discovery.db_config.config import database, login

import Alert_Discovery.db_config.config
grafana_url = Alert_Discovery.db_config.config.grafana_url.base_url
grafana_username = Alert_Discovery.db_config.config.grafana_url.username
grafana_password = Alert_Discovery.db_config.config.grafana_url.password
grafana_headers = Alert_Discovery.db_config.config.grafana_url.headers

grafana_alert_rules = Alert_Discovery.db_config.config.grafana_url.alert_rules
grafana_contact_points = Alert_Discovery.db_config.config.grafana_url.contact_points
grafana_notification_policies = Alert_Discovery.db_config.config.grafana_url.notification_policies
grafana_folders = Alert_Discovery.db_config.config.grafana_url.folders
grafana_dashboard = Alert_Discovery.db_config.config.grafana_url.dashboard
grafana_datasource = Alert_Discovery.db_config.config.grafana_url.datasource
grafana_panel = Alert_Discovery.db_config.config.grafana_url.panel

conn = database()
cur = conn.cursor()

app_g = Blueprint('app_g', __name__)


@app_g.route("/api/v1/get_alert_thresholds", methods=["GET"])
@login
def get_all_alert_thresholds(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()
        try:
            query = f"""select * from alerts"""
            cur.execute(query)
            cols = [column[0] for column in cur.description]
            rows = cur.fetchall()
            ll = []

            if len(rows) > 0:
                for eachRow in rows:
                    ll.append(dict(zip(cols, eachRow)))

                return jsonify({"type": "success", "alert_thresholds": ll})
            else:
                return jsonify({"type": "error", "message": "No alert thresholds found"})

        except Exception as e:
            return jsonify({"type": "error", "message": f"Error: {str(e)}"})
        finally:
            conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})


@app_g.route("/api/v1/single_alert_thresholds", methods=["GET"])
@login
def single_alert_thresholds(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()

        id = request.args.get('id')
        if not id:
            return jsonify({"message": "Alert ID is missing"}), 400

        try:
            query = f"""select * from alerts where alert_id={id}"""
            cur.execute(query)
            cols = [column[0] for column in cur.description]
            rows = cur.fetchall()
            ll = []

            if len(rows) > 0:
                for eachRow in rows:
                    ll.append(dict(zip(cols, eachRow)))

                return jsonify({"type": "success", "alert_details": ll})
            else:
                return jsonify({"type": "error", "message": f"No alert found with ID {id}"})

        except Exception as e:
            return jsonify({"type": "error", "message": f"Error: {str(e)}"})
        finally:
                conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})

@app_g.route("/api/v1/delete_alert_thresholds", methods=['DELETE'])
@login
def delete_alert_thresholds(*args):
    if args[0] == True:
        conn = database()
        cur = conn.cursor()

        id = request.args.get('id')
        if not id:
            return jsonify({"message": "Alert ID is missing"}), 400

        base_url = grafana_url
        s = requests.Session()
        s.auth = (grafana_username, grafana_password)

        try:
            query = """SELECT alert_uid from alerts WHERE alert_id='{0}' """.format(id)
            cur.execute(query)
            uid = cur.fetchone()[0]

            query = """DELETE from alerts WHERE alert_id={0}""".format(id)
            cur.execute(query)
            conn.commit()

            response = s.delete(base_url + f"{grafana_alert_rules}/{uid}")

            if response.status_code == 204:
                return jsonify({"result": "Success", "message": "Alert deleted successfully!!"})
            else:
                raise Exception(f"Failed to delete alert: External API returned status code {response.status_code}")

        except Exception as e:
            return jsonify({"type": "error", "message": f"Error: {str(e)}"})
        finally:
            conn.close()
    else:
        return ({"type": "error", "message": "Login failed"})

