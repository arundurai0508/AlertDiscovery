import psycopg2, schedule
from flask import Blueprint, request, jsonify
from functools import wraps

app_j = Blueprint('app_j', __name__)

flask_username = "autointelli"
flask_password = "autointelli"


def login(f):
    @wraps(f)
    def validate(*args, **kwargs):
        auth = request.authorization
        if auth and auth.username == flask_username and auth.password == flask_password:
            return f(True)
        else:
            return jsonify({'message': 'Login Failed !!'}), 401

    return validate


def database():
    conn = psycopg2.connect(host="localhost", dbname="Alert Rule Management", user="postgres", password='1234',
                            port=5432)
    return conn


class script_time():
    script = schedule.every(1).hours.do


class grafana_url():
    base_url = "http://app.autointelli.com:3000/"
    username = "admin"
    password = "Wigtra@autointelli1"
    headers = {
        'Content-Type': 'application/json',
        'X-Disable-Provenance': "true"
    }
    alert_rules = "api/v1/provisioning/alert-rules"
    contact_points = "api/v1/provisioning/contact-points"
    notification_policies = "api/v1/provisioning/policies"
    folders = "api/folders"
    dashboard = "api/search"
    datasource = "api/datasources"
    datasource_name = "api/datasources/name"
    panel = "api/dashboards/uid"
