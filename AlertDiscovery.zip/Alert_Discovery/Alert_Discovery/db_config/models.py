import psycopg2
from flask import Blueprint
from Alert_Discovery.db_config.config import database

conn = database()
app_k = Blueprint('app_k', __name__)


def database_table():
    try:
        alerts_query = (
            "CREATE TABLE alerts (alert_id SERIAL PRIMARY KEY, alert_title CHARACTER VARYING UNIQUE, alert_uid "
            "CHARACTER VARYING, dashboard_uid CHARACTER VARYING, panel_id CHARACTER VARYING, summary CHARACTER "
            "VARYING, threshold CHARACTER VARYING, panel_title CHARACTER VARYING, dashboard_name CHARACTER VARYING, metric CHARACTER VARYING);")

        dashboard_query = ("CREATE TABLE dashboard (id SERIAL PRIMARY KEY, dashboard_name CHARACTER VARYING UNIQUE, "
                           "dashboard_uid CHARACTER VARYING, folder_name CHARACTER VARYING, folder_uid CHARACTER VARYING, "
                           "datasource CHARACTER VARYING, datasource_uid CHARACTER VARYING, panel_details JSON);")

        contactpoints_query = ("CREATE TABLE contactpoints (contact_id SERIAL PRIMARY KEY, uid CHARACTER VARYING, "
                               "type CHARACTER VARYING, name CHARACTER VARYING, settings JSON, bottoken CHARACTER VARYING, "
                               "labels CHARACTER VARYING[]);")

        with conn, conn.cursor() as cur:

            cur.execute(alerts_query)
            cur.execute(dashboard_query)
            cur.execute(contactpoints_query)


    except Exception as e:

        print(f"Error creating tables: {e}")


database_table()
